/* background.js
 * 保存されているテーマカラーに合わせて、ツールバーのアイコンを同期させる。
 * options.js からのテーマ変更時にも呼ばれるが、ブラウザ起動直後・拡張機能の
 * 有効化直後にも確実に正しいアイコンになるよう、ここでも適用する。
 */

const VALID_ACCENTS = ["yellow", "coral", "sky", "mint", "lavender"];

async function syncActionIcon() {
  const { accent } = await chrome.storage.local.get(["accent"]);
  const theme = VALID_ACCENTS.includes(accent) ? accent : "yellow";
  try {
    await chrome.action.setIcon({
      path: {
        16: `icons/${theme}/icon16.png`,
        48: `icons/${theme}/icon48.png`,
        128: `icons/${theme}/icon128.png`
      }
    });
  } catch (e) {
    // アイコン設定に失敗しても致命的ではないため無視する
  }
}

chrome.runtime.onStartup.addListener(syncActionIcon);
chrome.runtime.onInstalled.addListener(syncActionIcon);

// options画面からのテーマ変更を受け取って即時反映
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.accent) {
    syncActionIcon();
  }
});

// content.js（ページに注入された合成ツール）からの要求を受けて、
// 設定タブ／ウィザードタブを開く。content script は runtime.openOptionsPage を
// 直接呼べないため、background 経由で仲介する。
chrome.runtime.onMessage.addListener((message) => {
  if (!message || typeof message !== "object") return;
  if (message.type === "openOptionsPage") {
    chrome.runtime.openOptionsPage();
  } else if (message.type === "openWizardTab") {
    chrome.tabs.create({ url: chrome.runtime.getURL("wizard.html") });
  }
});
