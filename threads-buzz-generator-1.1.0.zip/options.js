const providerEl = document.getElementById("provider");
const apiKeyEl = document.getElementById("apiKey");
const modelEl = document.getElementById("model");
const customUrlWrap = document.getElementById("customUrlWrap");
const customBaseUrlEl = document.getElementById("customBaseUrl");
const keyHintEl = document.getElementById("keyHint");
const modelHintEl = document.getElementById("modelHint");
const statusMsgEl = document.getElementById("statusMsg");
const costBadgeEl = document.getElementById("costBadge");

const KEY_HINTS = {
  openrouter: "OpenRouterのダッシュボード(Keys)で発行したキー。",
  anthropic: "Anthropic Consoleで発行したキー（sk-ant-...）。",
  openai: "OpenAI Platformで発行したキー（sk-...）。",
  gemini: "Google AI Studio（aistudio.google.com）の「Get API key」で発行。無料・カード登録不要。",
  custom: "利用するサービスが発行したAPIキー（不要な場合は空欄でも可）。"
};

const COST_INFO = {
  gemini: {
    ok: true,
    text: "🆓 無料で使えます。クレジットカード登録は不要です（1日1,000回まで無料）。"
  },
  openrouter: {
    ok: false,
    text: "💳 有料です。openrouter.aiでクレジットをチャージしてから使います（一部無料モデルもあります）。"
  },
  anthropic: {
    ok: false,
    text: "💳 有料です。生成のたびにクレジットカードへ課金されます（従量課金）。"
  },
  openai: {
    ok: false,
    text: "💳 有料です。生成のたびにクレジットカードへ課金されます（従量課金）。"
  },
  custom: {
    ok: null,
    text: "ℹ️ 料金は接続先のサービス次第です（自前サーバー等なら無料の場合もあります）。"
  }
};

function updateProviderUI() {
  const p = providerEl.value;
  keyHintEl.textContent = KEY_HINTS[p] || "";
  modelEl.placeholder = DEFAULT_MODELS[p] || "";
  modelHintEl.textContent = DEFAULT_MODELS[p]
    ? `空欄の場合のデフォルト: ${DEFAULT_MODELS[p]}`
    : "利用するモデルのIDを入力してください。";
  customUrlWrap.style.display = p === "custom" ? "block" : "none";

  const info = COST_INFO[p];
  if (info) {
    costBadgeEl.textContent = info.text;
    costBadgeEl.style.color = info.ok === true ? "var(--ok)" : info.ok === false ? "var(--danger)" : "var(--text-dim)";
    costBadgeEl.style.fontWeight = "700";
  } else {
    costBadgeEl.textContent = "";
  }
}

async function load() {
  await applyAccent();
  await renderSwatches();
  await renderAccounts();
  await renderStep1Status();
  await renderSetupBanner();

  const s = await getSettings();
  providerEl.value = s.provider || "gemini";
  apiKeyEl.value = s.apiKey || "";
  modelEl.value = s.model || "";
  customBaseUrlEl.value = s.customBaseUrl || "";
  updateProviderUI();
}

/* ---------------- 初期設定完了バナー ---------------- */
async function renderSetupBanner() {
  const el = document.getElementById("setupCompleteBanner");
  if (!el) return;
  const s = await getSettings();
  const accounts = await getAccounts();
  const step1Done = !!(s.provider && s.apiKey);
  const step2Done = accounts.length > 0;
  if (step1Done && step2Done) {
    el.innerHTML = `
      <div class="setup-banner">
        <span class="icon">✅</span>
        <div class="text"><b>初期設定が完了しました。</b><br/>このページを一度閉じて、ツールバーの拡張機能アイコンから開き直してください。</div>
      </div>`;
  } else {
    el.innerHTML = "";
  }
}

/* ---------------- ステップ状況表示 ---------------- */
async function renderStep1Status() {
  const el = document.getElementById("step1Status");
  if (!el) return;
  const s = await getSettings();
  if (s.provider && s.apiKey) {
    el.textContent = "✅ 設定済み";
    el.style.color = "var(--ok)";
  } else {
    el.textContent = "❌ 未設定";
    el.style.color = "var(--danger)";
  }
}

/* ---------------- アカウント管理 ---------------- */
async function renderAccounts() {
  const listEl = document.getElementById("accountList");
  const step2El = document.getElementById("step2Status");
  if (!listEl) return;
  const accounts = await getAccounts();
  const activeId = await getActiveAccountId();
  if (step2El) {
    if (accounts.length) {
      step2El.textContent = `✅ ${accounts.length}件登録済み`;
      step2El.style.color = "var(--ok)";
    } else {
      step2El.textContent = "❌ 未作成";
      step2El.style.color = "var(--danger)";
    }
  }
  if (!accounts.length) {
    listEl.innerHTML = `<p class="hint">まだ保存されたアカウントはありません。下の「新しいペルソナを作る」か、ファイル読み込みで追加してください。</p>`;
    return;
  }
  listEl.innerHTML = accounts
    .map(
      (a) => `
      <div class="radio-card" style="cursor:default;align-items:center;flex-wrap:wrap;">
        <div style="flex:1;min-width:120px;">
          <div class="title">${escapeHtml(a.name)}${
        a.id === activeId ? ' <span class="pill ok">使用中</span>' : ""
      }</div>
        </div>
        <button type="button" class="btn-secondary rename-account-btn" data-id="${a.id}">名前を変更</button>
        <button type="button" class="btn-secondary use-account-btn" data-id="${a.id}" ${
        a.id === activeId ? "disabled" : ""
      }>使用する</button>
        <button type="button" class="btn-ghost delete-account-btn" data-id="${a.id}" style="color:var(--danger);">削除</button>
      </div>`
    )
    .join("");

  listEl.querySelectorAll(".use-account-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await setActiveAccountId(btn.dataset.id);
      await renderAccounts();
    });
  });
  listEl.querySelectorAll(".rename-account-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const acc = accounts.find((a) => a.id === btn.dataset.id);
      if (!acc) return;
      const name = window.prompt("新しい名前を入力してください", acc.name);
      if (name && name.trim()) {
        await updateAccount(acc.id, { name: name.trim() });
        await renderAccounts();
      }
    });
  });
  listEl.querySelectorAll(".delete-account-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const acc = accounts.find((a) => a.id === btn.dataset.id);
      if (!acc) return;
      if (confirm(`「${acc.name}」を削除します。よろしいですか？`)) {
        await deleteAccount(acc.id);
        await renderAccounts();
        await renderSetupBanner();
      }
    });
  });
}

document.getElementById("openWizardBtn")?.addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("wizard.html") });
});

document.getElementById("importAccountFile")?.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const text = await file.text();
  document.getElementById("importAccountText").value = text;
  if (!document.getElementById("importAccountName").value.trim()) {
    document.getElementById("importAccountName").value = file.name.replace(/\.[^.]+$/, "");
  }
});

document.getElementById("importAccountBtn")?.addEventListener("click", async () => {
  const nameEl = document.getElementById("importAccountName");
  const textEl = document.getElementById("importAccountText");
  const msgEl = document.getElementById("importAccountMsg");
  const content = textEl.value.trim();
  if (!content) {
    msgEl.innerHTML = `<div class="msg error">ペルソナのテキストを貼り付けるか、ファイルを選択してください。</div>`;
    return;
  }
  await addAccount({ name: nameEl.value.trim(), profile: null, personaPrompt: content });
  nameEl.value = "";
  textEl.value = "";
  document.getElementById("importAccountFile").value = "";
  msgEl.innerHTML = `<div class="msg ok">✅ 新しいアカウントとして保存しました。</div>`;
  await renderAccounts();
  await renderSetupBanner();
});

async function renderSwatches() {
  const row = document.getElementById("swatchRow");
  if (!row) return;
  const current = await getAccent();
  row.innerHTML = VALID_ACCENTS.map(
    (a) =>
      `<button type="button" class="swatch${a === current ? " selected" : ""}" data-accent="${a}" style="background:${ACCENT_SWATCH_COLORS[a]}" title="${ACCENT_LABELS[a]}" aria-label="${ACCENT_LABELS[a]}" aria-pressed="${a === current}"></button>`
  ).join("");
  row.querySelectorAll(".swatch").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const accent = btn.dataset.accent;
      await saveAccent(accent);
      document.documentElement.setAttribute("data-accent", accent);
      await renderSwatches();
    });
  });
}

// スウォッチ自体の色は data-accent 適用前でも見えるよう、CSS変数と同じ値を直接指定する
const ACCENT_SWATCH_COLORS = {
  yellow: "#f3d94a",
  coral: "#f4a38a",
  sky: "#8fcbeb",
  mint: "#8fdcb4",
  lavender: "#c6b6f0"
};

providerEl.addEventListener("change", updateProviderUI);

async function ensureHostPermission(provider, customUrl) {
  if (provider !== "custom") return true;
  try {
    const origin = new URL(customUrl).origin + "/*";
    const granted = await chrome.permissions.request({ origins: [origin] });
    return granted;
  } catch (e) {
    statusMsgEl.innerHTML = `<div class="msg error">URLが正しくありません: ${e.message}</div>`;
    return false;
  }
}

document.getElementById("saveBtn").addEventListener("click", async () => {
  const provider = providerEl.value;
  const customBaseUrl = customBaseUrlEl.value.trim();

  if (provider === "custom") {
    const ok = await ensureHostPermission(provider, customBaseUrl);
    if (!ok) {
      statusMsgEl.innerHTML = `<div class="msg error">このURLへのアクセス許可がないと保存できません。</div>`;
      return;
    }
  }

  await saveSettings({
    provider,
    apiKey: apiKeyEl.value.trim(),
    model: modelEl.value.trim(),
    customBaseUrl
  });
  await renderStep1Status();
  await renderSetupBanner();
  const accounts = await getAccounts();
  statusMsgEl.innerHTML = accounts.length
    ? `<div class="msg ok">✅ 保存しました。</div>`
    : `<div class="msg ok">✅ 保存しました。次は下の「STEP 2」でペルソナを作成・読み込みしてください。</div>`;
});

document.getElementById("testBtn").addEventListener("click", async () => {
  statusMsgEl.innerHTML = `<div class="msg bot"><span class="spinner"></span>接続を確認しています...</div>`;
  // 保存前でもテストできるよう、一時的に現在の入力値で保存してからテスト
  const provider = providerEl.value;
  const customBaseUrl = customBaseUrlEl.value.trim();
  if (provider === "custom") {
    const ok = await ensureHostPermission(provider, customBaseUrl);
    if (!ok) {
      statusMsgEl.innerHTML = `<div class="msg error">このURLへのアクセス許可が必要です。</div>`;
      return;
    }
  }
  await saveSettings({
    provider,
    apiKey: apiKeyEl.value.trim(),
    model: modelEl.value.trim(),
    customBaseUrl
  });
  try {
    const reply = await testConnection();
    statusMsgEl.innerHTML = `<div class="msg ok">✅ 接続成功！応答: ${escapeHtml(
      reply.slice(0, 200)
    )}</div>`;
  } catch (e) {
    statusMsgEl.innerHTML = `<div class="msg error">❌ 接続に失敗しました:\n${escapeHtml(
      e.message
    )}</div>`;
  }
});

document.getElementById("resetBtn").addEventListener("click", async () => {
  if (confirm("保存されているすべてのアカウント（プロフィール・ペルソナ設定）を削除します。よろしいですか？")) {
    await clearAll();
    statusMsgEl.innerHTML = `<div class="msg ok">✅ リセットしました。</div>`;
    await renderAccounts();
    await renderSetupBanner();
  }
});

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

load();
