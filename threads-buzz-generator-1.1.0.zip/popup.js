async function init() {
  await applyAccent();
  const s = await getSettings();
  const label = document.getElementById("providerLabel");
  const statusArea = document.getElementById("statusArea");
  const hasApiKey = !!(s.provider && s.apiKey);
  if (hasApiKey) {
    label.textContent = `${PROVIDER_LABELS[s.provider] || s.provider}${
      s.model ? " / " + s.model : ""
    }`;
  } else {
    label.textContent = "未設定";
  }

  const accountLabel = document.getElementById("accountLabel");
  const account = await getActiveAccount();
  if (accountLabel) {
    accountLabel.textContent = account ? account.name : "未作成";
  }

  if (!hasApiKey) {
    statusArea.innerHTML =
      '<div class="msg error">まだ使えません。「⚙️ AI連携の設定」で STEP 1（APIキー）と STEP 2（ペルソナ）を両方済ませてください。</div>';
  } else if (!account) {
    statusArea.innerHTML =
      '<div class="msg error">APIキーは設定済みですが、ペルソナが未作成です。「⚙️ AI連携の設定」の STEP 2 で作成・読み込みしてください。</div>';
  }
}

document.getElementById("openBtn").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("wizard.html") });
});

document.getElementById("mergeBtn").addEventListener("click", async () => {
  const mergeStatusEl = document.getElementById("mergeStatus");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error("no-tab");
    // 今見ているページの右上に、フローティングツールとして直接表示する
    // （参考ツールと同じ方式：別ウィンドウは開かず、activeTab + scripting で注入）
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["common.js", "content.js"]
    });
    window.close();
  } catch (e) {
    if (mergeStatusEl) {
      mergeStatusEl.innerHTML =
        '<div class="msg error">このページでは実行できませんでした。Chromeの内部ページ（chrome://…）や拡張機能ストアでは動作しません。通常のWebページ（Threadsなど）を開いた状態でお試しください。</div>';
    }
  }
});

document.getElementById("optionsBtn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

init();
