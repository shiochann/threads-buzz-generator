/* wizard.js — Threads バズ投稿ジェネレーターのメインフロー */

const PROFILE_LABELS = [
  ["name", "名前・肩書き"],
  ["genre", "事業内容・ジャンル"],
  ["achievements", "実績・数字"],
  ["mainProduct", "メイン商材・テーマ"],
  ["target", "ターゲット読者"],
  ["revenueModel", "収益モデル"],
  ["products", "販売コンテンツ・商品"],
  ["tone", "口調・キャラクター"],
  ["numbers", "使える数字リスト"],
  ["ngWords", "絶対NGワード"],
  ["ctaFollow", "フォロー誘導文"],
  ["ctaOptin", "オプチャ/LINE誘導文"]
];

const Q_LIST = [
  {
    key: "achievements",
    q: "Q1. あなたの実績や権威性を教えてください。",
    hint: "例：「スキンケア歴10年、美容部員出身」「3人育児しながら-15kg達成」「元保育士10年」\n※数字が入るとベストです。なければ経験年数やユニークな経歴でもOK。"
  },
  {
    key: "target",
    q: "Q2. 誰に向けて発信しますか？",
    hint: "例：「肌荒れに悩む20〜30代の女性」「育児中で自分の時間が取れないママ」\n※年齢・職業・悩みが入るとより具体的になります。"
  },
  {
    key: "revenueModel",
    q: "Q3. Threadsでの収益モデルを教えてください。",
    hint: "A）アフィリエイト専門　B）コンテンツ販売専門　C）アフィリ＋コンテンツ販売（両方）　D）まだ決めていない",
    choices: ["A）アフィリエイト専門", "B）コンテンツ販売専門", "C）アフィリ＋コンテンツ販売（両方）", "D）まだ決めていない"]
  },
  {
    key: "products",
    q: "Q4. 販売している（または予定している）商品・コンテンツを教えてください。",
    hint: "例：「毛穴ケアの完全ガイドnote（1,980円）」「育児ストレス解消オンライン講座」\n※まだない場合は「なし」でOK。"
  },
  {
    key: "tone",
    q: "Q5. どんなキャラクター・口調で発信しますか？",
    hint: "例：「関西弁混じり、リアルで飾らない」「丁寧語ベース、でも親しみやすく」「毒舌、本音ベース」\n※「まだ決めていない」でもOKです。"
  },
  {
    key: "numbers",
    q: "Q6. 投稿で使える具体的な数字を教えてください。",
    hint: "例：「フォロワー〇〇人」「継続〇年」「-〇〇kg減量達成」「肌悩み改善〇〇人サポート」\n※思いつく限り列挙してください。"
  }
];

const STEP_DOTS = ["入力", "確認", "ペルソナ", "投稿生成"];

let state = {
  step: "loading",
  route: null,
  qIndex: 0,
  answers: {},
  files: [],
  pastText: "",
  profile: null,
  personaPrompt: "",
  originalPost: "",
  accountId: null, // 編集中/使用中のアカウントID（nullなら新規作成）
  accountName: "",
  accounts: [], // アカウント選択画面用のキャッシュ
  chat: [] // {role:'user'|'assistant', content:string}
};

const contentEl = document.getElementById("content");
const stepsEl = document.getElementById("steps");

document.getElementById("settingsBtn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});
document.getElementById("resetBtn").addEventListener("click", async () => {
  if (confirm("最初からやり直します。入力中の内容は失われますが、保存済みのアカウントは削除されません。よろしいですか？")) {
    state = {
      step: "loading",
      route: null,
      qIndex: 0,
      answers: {},
      files: [],
      pastText: "",
      profile: null,
      personaPrompt: "",
      originalPost: "",
      accountId: null,
      accountName: "",
      accounts: [],
      chat: []
    };
    boot();
  }
});

function renderStepDots(activeIndex) {
  stepsEl.innerHTML = STEP_DOTS.map((label, i) => {
    const cls = i < activeIndex ? "done" : i === activeIndex ? "active" : "";
    return `<div class="step-dot ${cls}" title="${label}">${i + 1}</div>`;
  }).join("");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : str;
  return div.innerHTML;
}

async function copyToClipboard(text, btn) {
  try {
    await navigator.clipboard.writeText(text);
    if (btn) {
      const orig = btn.textContent;
      btn.textContent = "✅ コピーしました";
      setTimeout(() => (btn.textContent = orig), 1500);
    }
  } catch (e) {
    alert("コピーに失敗しました: " + e.message);
  }
}

/* ---------------- 起動時: 既存プロフィールの有無を確認 ---------------- */
async function boot() {
  await applyAccent();
  const settings = await getSettings();
  if (!settings.provider || !settings.apiKey) {
    state.step = "needSettings";
    render();
    return;
  }
  const accounts = await getAccounts();
  state.accounts = accounts;
  if (accounts.length === 0) {
    state.step = "route";
    render();
  } else if (accounts.length === 1) {
    const acc = accounts[0];
    state.accountId = acc.id;
    state.accountName = acc.name;
    state.profile = acc.profile;
    state.personaPrompt = acc.personaPrompt;
    await setActiveAccountId(acc.id);
    state.step = "resumeChoice";
    render();
  } else {
    const activeId = await getActiveAccountId();
    const active = accounts.find((a) => a.id === activeId);
    if (active) {
      state.accountId = active.id;
      state.accountName = active.name;
      state.profile = active.profile;
      state.personaPrompt = active.personaPrompt;
    }
    state.step = "accountSelect";
    render();
  }
}

/* ---------------- レンダリング ディスパッチ ---------------- */
function render() {
  const badge = document.getElementById("accountBadge");
  if (badge) badge.textContent = state.accountName ? `👤 ${state.accountName}` : "";
  switch (state.step) {
    case "needSettings":
      renderStepDots(-1);
      contentEl.innerHTML = `
        <div class="card">
          <h2>先にAI連携を設定してください</h2>
          <p>Gemini / Claude / OpenAI / OpenRouter など、使いたいAIのAPIキーを登録すると使えるようになります。<br/>
          お金をかけずに試したい場合は「Google（Gemini）」がおすすめです。カード登録不要で無料枠だけで使えます。</p>
          <button class="btn-primary" id="goSettings">⚙️ 設定を開く</button>
        </div>`;
      document.getElementById("goSettings").onclick = () =>
        chrome.runtime.openOptionsPage();
      break;
    case "resumeChoice":
      renderStepDots(2);
      contentEl.innerHTML = `
        <div class="card">
          <h2>「${escapeHtml(state.accountName || "以前作成したペルソナ")}」が見つかりました</h2>
          <p>このペルソナで続けて投稿を作りますか？それとも別のアカウント用に新しく作りますか？</p>
          <div class="btn-row">
            <button class="btn-secondary" id="restartAll">＋ 新しいアカウントを追加</button>
            <span class="spacer"></span>
            <button class="btn-primary" id="continueChat">このペルソナで投稿を作る →</button>
          </div>
        </div>`;
      document.getElementById("restartAll").onclick = () => {
        state.step = "route";
        state.accountId = null;
        state.accountName = "";
        state.profile = null;
        state.personaPrompt = "";
        render();
      };
      document.getElementById("continueChat").onclick = () => {
        state.step = "chat";
        state.chat = [];
        render();
      };
      break;
    case "accountSelect":
      renderAccountSelect();
      break;
    case "route":
      renderRoute();
      break;
    case "intakeA":
      renderIntakeA();
      break;
    case "intakeB":
      renderIntakeB();
      break;
    case "synthesizing":
      renderSynthesizing();
      break;
    case "profileReview":
      renderProfileReview();
      break;
    case "personaReady":
      renderPersonaReady();
      break;
    case "chat":
      renderChat();
      break;
    default:
      contentEl.innerHTML = `<div class="card">読み込み中...</div>`;
  }
}

/* ---------------- STEP: アカウント選択（複数アカウント登録時） ---------------- */
function renderAccountSelect() {
  renderStepDots(-1);
  const accounts = state.accounts || [];
  const rows = accounts
    .map(
      (a) => `
      <div class="radio-card" data-id="${a.id}" style="align-items:center;">
        <div style="flex:1;">
          <div class="title">${escapeHtml(a.name)}</div>
          <div class="desc">${escapeHtml((a.profile && a.profile.genre) || "")}</div>
        </div>
        <button type="button" class="btn-primary use-account-btn" data-id="${a.id}">このアカウントで進める →</button>
      </div>`
    )
    .join("");
  contentEl.innerHTML = `
    <div class="card">
      <h2>使うアカウントを選んでください</h2>
      <p>複数のペルソナ設定が保存されています。使うアカウントを選ぶか、新しく追加してください。</p>
      ${rows}
      <div class="btn-row" style="margin-top:14px;">
        <span class="spacer"></span>
        <button class="btn-secondary" id="newAccountBtn">＋ 新しいアカウントを追加</button>
      </div>
    </div>`;
  contentEl.querySelectorAll(".use-account-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const acc = accounts.find((a) => a.id === btn.dataset.id);
      if (!acc) return;
      await setActiveAccountId(acc.id);
      state.accountId = acc.id;
      state.accountName = acc.name;
      state.profile = acc.profile;
      state.personaPrompt = acc.personaPrompt;
      state.step = "chat";
      state.chat = [];
      render();
    });
  });
  document.getElementById("newAccountBtn").onclick = () => {
    state.accountId = null;
    state.accountName = "";
    state.profile = null;
    state.personaPrompt = "";
    state.step = "route";
    render();
  };
}

/* ---------------- STEP: ルート選択 ---------------- */
function renderRoute() {
  renderStepDots(0);
  contentEl.innerHTML = `
    <div class="card">
      <h2>まず確認させてください</h2>
      <p>あなたはどちらですか？</p>
      <div class="radio-card" id="routeA">
        <input type="radio" name="route" />
        <div>
          <div class="title">A）すでにThreadsで発信中</div>
          <div class="desc">過去の投稿スクリーンショットやCSV、自己紹介文などがある</div>
        </div>
      </div>
      <div class="radio-card" id="routeB">
        <input type="radio" name="route" />
        <div>
          <div class="title">B）これからThreadsを始める</div>
          <div class="desc">データはまだない。6つの質問に答えて0からペルソナを作る</div>
        </div>
      </div>
      <div class="btn-row"><span class="spacer"></span>
        <button class="btn-primary" id="routeNext" disabled>次へ →</button>
      </div>
    </div>`;
  const rA = document.getElementById("routeA");
  const rB = document.getElementById("routeB");
  const nextBtn = document.getElementById("routeNext");
  function pick(route) {
    state.route = route;
    rA.classList.toggle("selected", route === "A");
    rB.classList.toggle("selected", route === "B");
    rA.querySelector("input").checked = route === "A";
    rB.querySelector("input").checked = route === "B";
    nextBtn.disabled = false;
  }
  rA.onclick = () => pick("A");
  rB.onclick = () => pick("B");
  nextBtn.onclick = () => {
    if (state.route === "A") {
      state.step = "intakeA";
    } else {
      state.qIndex = 0;
      state.step = "intakeB";
    }
    render();
  };
}

/* ---------------- STEP: ルートA（発信者）データ提出 ---------------- */
function renderIntakeA() {
  renderStepDots(0);
  const thumbs = state.files
    .map((f, i) => `<img src="data:${f.mediaType};base64,${f.base64}" title="${escapeHtml(f.name)}" />`)
    .join("");
  contentEl.innerHTML = `
    <div class="card">
      <h2>過去の投稿データを渡してください</h2>
      <p>渡せるものを1つ以上：Threadsのスクリーンショット（複数OK）、投稿をまとめたCSV/テキスト、自己紹介文など。<br/>
      ※閲覧数・いいね数が見えるスクショがあると、より精度が上がります。<br/>
      ※PDFはテキストをコピーして下の欄に貼り付けてください。</p>
      <div class="file-drop" id="dropZone">📎 クリックして画像・CSV・テキストファイルを選択</div>
      <input type="file" id="fileInput" multiple accept="image/*,.csv,.txt" style="display:none" />
      <div class="thumb-row">${thumbs}</div>
      <label>または、投稿テキスト・自己紹介文などを直接貼り付け</label>
      <textarea id="pastText" placeholder="過去投稿のテキストや自己紹介文をここに貼り付け...">${escapeHtml(state.pastText)}</textarea>
      <div class="btn-row">
        <button class="btn-secondary" id="backBtn">← 戻る</button>
        <span class="spacer"></span>
        <button class="btn-primary" id="nextBtn">この内容でプロフィールを作成 →</button>
      </div>
    </div>`;
  document.getElementById("backBtn").onclick = () => {
    state.step = "route";
    render();
  };
  document.getElementById("dropZone").onclick = () =>
    document.getElementById("fileInput").click();
  document.getElementById("fileInput").onchange = async (e) => {
    await handleFiles(e.target.files);
    render();
  };
  document.getElementById("pastText").oninput = (e) => {
    state.pastText = e.target.value;
  };
  document.getElementById("nextBtn").onclick = async () => {
    if (!state.files.length && !state.pastText.trim()) {
      alert("画像・ファイル・テキストのいずれかを渡してください。");
      return;
    }
    await runSynthesis();
  };
}

async function handleFiles(fileList) {
  for (const file of fileList) {
    if (file.type.startsWith("image/")) {
      const { base64, mediaType } = await fileToBase64(file);
      state.files.push({ base64, mediaType, name: file.name });
    } else if (
      file.type === "text/csv" ||
      file.type === "text/plain" ||
      /\.(csv|txt)$/i.test(file.name)
    ) {
      const text = await file.text();
      state.pastText += `\n\n----- ${file.name} -----\n${text}`;
    } else {
      alert(
        `${file.name} は非対応の形式です。画像・CSV・テキストのみ対応しています（PDFはテキストを貼り付けてください）。`
      );
    }
  }
}

/* ---------------- STEP: ルートB（初心者）6問インタビュー ---------------- */
function renderIntakeB() {
  renderStepDots(0);
  const q = Q_LIST[state.qIndex];
  const total = Q_LIST.length;
  const choicesHtml = q.choices
    ? `<div>${q.choices
        .map(
          (c) =>
            `<button class="btn-secondary choice-btn" style="display:block;width:100%;text-align:left;margin-bottom:6px;">${escapeHtml(
              c
            )}</button>`
        )
        .join("")}</div>`
    : "";
  contentEl.innerHTML = `
    <div class="card">
      <p class="hint">質問 ${state.qIndex + 1} / ${total}</p>
      <h2>${escapeHtml(q.q)}</h2>
      <p style="white-space:pre-wrap;">${escapeHtml(q.hint)}</p>
      ${choicesHtml}
      <textarea id="answerInput" placeholder="ここに回答を入力...">${escapeHtml(
        state.answers[q.key] || ""
      )}</textarea>
      <div class="btn-row">
        <button class="btn-secondary" id="backBtn">← 戻る</button>
        <span class="spacer"></span>
        <button class="btn-primary" id="nextBtn">${
          state.qIndex === total - 1 ? "回答を整理する →" : "次の質問へ →"
        }</button>
      </div>
    </div>`;

  if (q.choices) {
    contentEl.querySelectorAll(".choice-btn").forEach((btn, i) => {
      btn.onclick = () => {
        document.getElementById("answerInput").value = q.choices[i];
      };
    });
  }

  document.getElementById("backBtn").onclick = () => {
    if (state.qIndex === 0) {
      state.step = "route";
    } else {
      state.qIndex--;
    }
    render();
  };
  document.getElementById("nextBtn").onclick = async () => {
    const val = document.getElementById("answerInput").value.trim();
    if (!val) {
      alert("回答を入力してください。");
      return;
    }
    state.answers[q.key] = val;
    if (state.qIndex < total - 1) {
      state.qIndex++;
      render();
    } else {
      await runSynthesis();
    }
  };
}

/* ---------------- AI呼び出し: プロフィール抽出/整理 ---------------- */
const PROFILE_FORMAT_INSTRUCTIONS = `以下の項目を、指定したラベルと「：」を使い、1項目1行以上で必ずこの順番・この日本語ラベルのまま出力してください。
情報が読み取れない・答えられない項目は「不明」と記載し、絶対に推測で埋めないでください（ただし絶対NGワード・CTA設定・使える数字リストは、他の情報から自然に導けるものを提案してよい）。
余計な前置きや説明文は一切書かず、この形式のみを出力してください。

名前・肩書き：
事業内容・ジャンル：
実績・数字：
メイン商材・テーマ：
ターゲット読者：
収益モデル：
販売コンテンツ・商品：
口調・キャラクター：
使える数字リスト：
- (箇条書きで、なければ「なし」)
絶対NGワード：
フォロー誘導文：
オプチャ/LINE誘導文：`;

async function runSynthesis() {
  state.step = "synthesizing";
  render();
  try {
    let userContent, images;
    if (state.route === "A") {
      userContent = `以下はSNS発信者から提供された過去投稿データ・自己紹介文です。この情報をもとにプロフィールを抽出してください。\n\n${
        state.pastText || "（テキスト情報なし。添付画像のみを参照してください）"
      }\n\n${PROFILE_FORMAT_INSTRUCTIONS}`;
      images = state.files;
    } else {
      const lines = Q_LIST.map(
        (q) => `${q.q}\n回答: ${state.answers[q.key]}`
      ).join("\n\n");
      userContent = `以下はSNS発信者への6問インタビューの回答です。この情報をもとにプロフィールを整理してください。事業内容・ジャンルや名前・肩書き、メイン商材・テーマは回答内容から自然に推測して構いません。絶対NGワードとCTA設定は収益モデル・ジャンルに合わせて自動で作成してください。\n\n${lines}\n\n${PROFILE_FORMAT_INSTRUCTIONS}`;
      images = [];
    }
    const system =
      "あなたはSNS発信者のプロフィールをヒアリングして整理する、優秀なマーケティングアシスタントです。指示されたフォーマットだけを正確に出力してください。";
    const reply = await callAI({
      system,
      messages: [{ role: "user", content: userContent, images }]
    });
    const parsed = parseProfileText(reply);
    state.profile = parsed;
    state.step = "profileReview";
    render();
  } catch (e) {
    state.step = state.route === "A" ? "intakeA" : "intakeB";
    render();
    const box = document.createElement("div");
    box.className = "msg error";
    box.textContent = "プロフィールの生成に失敗しました: " + e.message;
    contentEl.prepend(box);
  }
}

function renderSynthesizing() {
  renderStepDots(1);
  contentEl.innerHTML = `<div class="card"><span class="spinner"></span>AIがプロフィールを整理しています...</div>`;
}

function parseProfileText(text) {
  const labelMap = {
    "名前・肩書き": "name",
    "事業内容・ジャンル": "genre",
    "実績・数字": "achievements",
    "メイン商材・テーマ": "mainProduct",
    "ターゲット読者": "target",
    "収益モデル": "revenueModel",
    "販売コンテンツ・商品": "products",
    "口調・キャラクター": "tone",
    "使える数字リスト": "numbers",
    "絶対NGワード": "ngWords",
    "フォロー誘導文": "ctaFollow",
    "オプチャ/LINE誘導文": "ctaOptin",
    "オプチャ・LINE誘導文": "ctaOptin"
  };
  const profile = {};
  PROFILE_LABELS.forEach(([k]) => (profile[k] = ""));

  const lines = text.split(/\r?\n/);
  let currentKey = null;
  const labelPattern = Object.keys(labelMap).sort((a, b) => b.length - a.length);

  for (let rawLine of lines) {
    const line = rawLine.replace(/^[・\-\*\s]+/, "").trim();
    let matched = false;
    for (const label of labelPattern) {
      const re = new RegExp("^" + label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\s*[:：]\\s*(.*)$");
      const m = line.match(re);
      if (m) {
        currentKey = labelMap[label];
        profile[currentKey] = m[1].trim();
        matched = true;
        break;
      }
    }
    if (!matched && currentKey) {
      // 複数行にまたがる値（使える数字リストなど）を追記
      if (rawLine.trim()) {
        profile[currentKey] = profile[currentKey]
          ? profile[currentKey] + "\n" + rawLine.trim()
          : rawLine.trim();
      }
    }
  }
  return profile;
}

/* ---------------- STEP: プロフィール確認・編集 ---------------- */
function renderProfileReview() {
  renderStepDots(1);
  const p = state.profile || {};
  const fieldsHtml = PROFILE_LABELS.map(([key, label]) => {
    const isTextarea = key === "numbers" || key === "ngWords";
    const val = escapeHtml(p[key] || "");
    return `
      <label>${label}</label>
      ${
        isTextarea
          ? `<textarea data-key="${key}">${val}</textarea>`
          : `<input type="text" data-key="${key}" value="${val}" />`
      }`;
  }).join("");

  contentEl.innerHTML = `
    <div class="card">
      <h2>プロフィールを確認してください</h2>
      <p>AIが読み取った内容です。修正・追加があれば自由に編集してください。「不明」のままでも進められます。</p>
      <p class="hint">※CTAはフォロー誘導・オプチャ/LINE誘導のどちらか片方だけを使うのが基本です（もう片方は空欄でOK）。</p>
      ${fieldsHtml}
      <div class="btn-row">
        <button class="btn-secondary" id="backBtn">← やり直す</button>
        <span class="spacer"></span>
        <button class="btn-primary" id="confirmBtn">この内容で確定 → ペルソナ作成 →</button>
      </div>
    </div>`;

  document.getElementById("backBtn").onclick = () => {
    state.step = state.route === "A" ? "intakeA" : "intakeB";
    render();
  };
  document.getElementById("confirmBtn").onclick = async () => {
    const updated = {};
    contentEl.querySelectorAll("[data-key]").forEach((el) => {
      updated[el.dataset.key] = el.value.trim();
    });
    state.profile = updated;
    state.personaPrompt = assemblePersonaPrompt(updated);
    if (state.accountId) {
      await updateAccount(state.accountId, {
        profile: updated,
        personaPrompt: state.personaPrompt
      });
    } else {
      const account = await addAccount({
        profile: updated,
        personaPrompt: state.personaPrompt
      });
      state.accountId = account.id;
      state.accountName = account.name;
    }
    state.step = "personaReady";
    render();
  };
}

/* ---------------- ペルソナプロンプト組み立て（テンプレート） ---------------- */
function assemblePersonaPrompt(p) {
  const val = (v, fallback = "不明") => (v && v.trim() ? v.trim() : fallback);
  const numbersBlock = val(p.numbers, "特になし");
  const ctaFollowLine = val(p.ctaFollow, "（未使用）");
  const ctaOptinLine = val(p.ctaOptin, "（未使用）");

  return `あなたはThreadsのバズ投稿専門ライターです。
以下のペルソナ・ルールに従って、渡された元投稿を書き直してください。
2ステップで進めます。必ずSTEP1の回答後に止まり、選択を待ってください。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
発信者プロフィール
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

・名前・肩書き：${val(p.name)}
・事業内容・ジャンル：${val(p.genre)}
・実績・数字：${val(p.achievements)}
・メイン商材・テーマ：${val(p.mainProduct)}
・ターゲット読者：${val(p.target)}
・収益モデル：${val(p.revenueModel)}
・販売コンテンツ・商品：${val(p.products)}
・口調・キャラクター：${val(p.tone)}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
使える数字リスト
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${numbersBlock}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
絶対NGワード
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${val(p.ngWords, "特になし")}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CTA設定
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

・フォロー誘導文：${ctaFollowLine}
・オプチャ/LINE誘導文：${ctaOptinLine}
CTAは1つだけ。両方入れない。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
参照情報について
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

上記プロフィール・数字リストをもとに投稿を作成する。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ 最重要：変換の基本思想
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

元投稿は「設計図」。自分の情報は「素材」。
設計図を崩さず、素材を差し込む作業がこのプロンプトのすべて。
自分らしさを出そうとして設計図を崩すのは絶対にNG。
口調・数字・エピソードが豊富でも、元投稿の型が最優先。

【ロック項目（絶対に変えてはいけない）】
・冒頭フックの構文・リズム：構文・句読点・改行位置をそのまま維持する
・箇条書きの数：元投稿が4項目なら4項目。絶対に増減しない
・箇条書きの並び順の論理：「大→小」「原因→結果」などの論理順を維持する
・締めの構文とリズム：「↓」の使い方・余韻の残し方・最終行の文字数感
・対比・煽り・ストーリーの流れ：対比や展開があれば、その流れは崩さない
・1文の長さ感：短文主体なら短文のまま。長文主体なら長文のまま

【スワップ項目（置き換えていい要素）】
・各箇条書きの中身 → 自分のジャンル・事業ネタ
・固有名詞 → 自分のサービス名・商材名など
・数字 → 上記「使える数字リスト」から
・ジャンル用語 → 自分のジャンルに合う言葉に変換

【変換作業のセルフチェック】
□ 冒頭フックの構文・句読点・改行位置は元投稿と同じか
□ 箇条書きの数は元投稿と同じか
□ 締めのリズム・「↓」の使い方は元投稿と同じか
□ 1文の長さ感は元投稿と揃っているか
□ 設計図が崩れていたら書き直す

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
口調・文体ルール
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

上記プロフィールの「口調・キャラクター」に合わせて書く。
・話し言葉ベース（書き言葉・丁寧すぎる文章はNG）
・「w」を自然に使う（多用しない）
・短文。1文が長くなりすぎない
・飾らない。リアルな感情が出る
・ライター臭・丁寧すぎる文章は絶対NG

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
伸びやすい言い回しパターン（スワップ箇所にのみ使う）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

・誇張表現：「ビビるほど〜」「えぐいことが〜」「マジで〜」「ヤバい」
・命令語尾：「〜しろ」「〜するな」「〜やれ」「〜しといて」
・笑い：「ww」「w」（多用しない。1〜2個が自然）
・損失回避：「〜はマジでもったいない」「〜で損してるかもしれんぞ」
・簡易性：「これだけでいい」「これだけやれ」「1個だけやれ」
・自己開示：「ぶっちゃけると」「正直に言う」「俺の場合は」
・日常リアル描写：「朝起きたら〜してた」「寝る前に〜した」

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
バズ構成ルール
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. 具体的な数字を必ず1つ以上入れる
2. 1投稿1メッセージ。詰め込まない
3. 最後に自然なCTA（フォロー・オプチャ誘導）を入れてもよい

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 1：テーマ提案（ここで必ず止まる）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

元投稿を読み、以下を同時に行う。
1. プロフィール情報をもとに相性のいいテーマを考える
2. 以下のテーマ軸から組み合わせて候補を7〜8個提案する

【テーマ軸】
・損失回避：「やらないと損」「知らないと置いてかれる」
・簡易性：「これだけでいい」「1個だけやれ」
・新規性：「ほとんどの人が知らない」「まだ誰もやってない」
・意外性・常識破壊：「普通と逆のことをやってる」
・社会的証明：「月商○○万の自分がやってること」
・共感・自己開示：「昔の自分に言いたい」「失敗したからこそ言える」
・好奇心・ティザー：「これ知ってる人いる？」「ぶっちゃけると」

【出力形式（STEP1）】

【投稿傾向メモ】
・伸びてる角度：
・まだやってない角度：

【テーマ候補】
① [軸] タイトル
→ フック例：「〜〜〜」
→ 使うエピソード/数字：
→ 一言メモ：
②〜⑧（以下同様）

提案後、「どれにしますか？複数選んでもOKです」と聞いて止まる。
STEP2には絶対に進まない。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 2：投稿作成（選択後に実行）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

選ばれたテーマで投稿を2〜3本作る。

【作成手順（必ず守る）】
1. 元投稿の「ロック項目」を書き出す
2. ロック項目を骨格として固定する
3. スワップ項目だけを自分のネタに置き換える
4. セルフチェックを実施し、崩れがあれば修正する

必ず確定したプロフィールの実数字・エピソードを1つ以上差し込む。
伸びてる言い回しパターンはスワップ箇所にのみ使う。

【出力形式（STEP2）】

【元投稿から抽出したロック項目】
・冒頭フック構文：
・箇条書き数：○個
・締めの構文：

【パターンA】
（投稿本文）

【パターンB】
（投稿本文）

【パターンC】
（投稿本文）※任意

【元投稿から活かした構成・表現】
（1〜3行）

【使ったエピソード/数字】
（どの情報を使ったか）

【3本の中でのおすすめ】
（どれが一番バズりそうか、理由も一言で）`;
}

/* ---------------- STEP: ペルソナ完成 ---------------- */
function renderPersonaReady() {
  renderStepDots(2);
  contentEl.innerHTML = `
    <div class="card">
      <h2>✅ 「${escapeHtml(state.accountName || "あなた専用")}」のペルソナが完成しました</h2>
      <p>これがこのアカウントのThreadsバズ投稿AIライターの設定です。このまま次に進むと、この設定を使って投稿を生成できます。「⚙️ 設定」のアカウント管理から、いつでも名前を変更したり別のアカウントに切り替えたりできます。</p>
      <div class="output-box">${escapeHtml(state.personaPrompt)}</div>
      <div class="btn-row">
        <button class="btn-secondary copy-btn" id="copyBtn">📋 テキストをコピー</button>
        <span class="spacer"></span>
        <button class="btn-secondary" id="editBtn">← プロフィールを編集</button>
        <button class="btn-primary" id="nextBtn">投稿を作る →</button>
      </div>
    </div>`;
  document.getElementById("copyBtn").onclick = (e) =>
    copyToClipboard(state.personaPrompt, e.target);
  document.getElementById("editBtn").onclick = () => {
    state.step = "profileReview";
    render();
  };
  document.getElementById("nextBtn").onclick = () => {
    state.step = "chat";
    state.chat = [];
    render();
  };
}

/* ---------------- STEP: 投稿生成チャット ---------------- */
function extractPatternCards(text) {
  const re = /【パターン([A-Z])】\s*([\s\S]*?)(?=【パターン[A-Z]】|【元投稿から活かした構成|【使ったエピソード|【3本の中で|$)/g;
  const cards = [];
  let m;
  while ((m = re.exec(text)) !== null) {
    const body = m[2].trim();
    if (body) cards.push({ label: m[1], body });
  }
  return cards;
}

function renderChat() {
  renderStepDots(3);
  const chatHtml = state.chat
    .map((msg) => {
      if (msg.role === "user") {
        return `<div class="msg user"><b>あなた：</b>\n${escapeHtml(
          msg.content
        )}</div>`;
      }
      const cards = extractPatternCards(msg.content);
      const cardsHtml = cards
        .map(
          (c) => `
        <div class="pattern-card">
          <h3>パターン${c.label}</h3>
          <div class="body">${escapeHtml(c.body)}</div>
          <button class="btn-secondary copy-btn pattern-copy" data-text="${encodeURIComponent(
            c.body
          )}">📋 この投稿をコピー</button>
        </div>`
        )
        .join("");
      return `<div class="msg bot"><b>🤖 AI：</b>\n${escapeHtml(msg.content)}</div>${cardsHtml}`;
    })
    .join("");

  const isFirst = state.chat.length === 0;

  contentEl.innerHTML = `
    <div class="card">
      <h2>投稿を作る</h2>
      <p class="hint">${
        isFirst
          ? "バズっていた投稿（他SNSで伸びていた投稿）のテキストをそのまま貼り付けて送信してください。テーマが7〜8個提案されます。"
          : "テーマを選んだり、修正の指示を送ったりできます。（例：「②と⑤にします」「もっと数字を強調して」）"
      }</p>
      <div id="chatLog">${chatHtml}</div>
      <div id="loadingArea"></div>
      <textarea id="chatInput" placeholder="${
        isFirst ? "ここにバズっていた投稿を貼り付け..." : "ここに返信を入力..."
      }"></textarea>
      <div class="btn-row">
        <button class="btn-secondary" id="editPersonaBtn">← ペルソナを編集</button>
        <span class="spacer"></span>
        <button class="btn-primary" id="sendBtn">送信 →</button>
      </div>
    </div>`;

  document.getElementById("editPersonaBtn").onclick = () => {
    state.step = "personaReady";
    render();
  };

  contentEl.querySelectorAll(".pattern-copy").forEach((btn) => {
    btn.onclick = () => copyToClipboard(decodeURIComponent(btn.dataset.text), btn);
  });

  const log = document.getElementById("chatLog");
  log.scrollTop = log.scrollHeight;

  document.getElementById("sendBtn").onclick = sendChatMessage;
  document.getElementById("chatInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      sendChatMessage();
    }
  });
}

async function sendChatMessage() {
  const input = document.getElementById("chatInput");
  const text = input.value.trim();
  if (!text) return;
  state.chat.push({ role: "user", content: text });
  render();
  document.getElementById("loadingArea").innerHTML =
    '<div class="msg bot"><span class="spinner"></span>AIが考えています...</div>';
  document.getElementById("sendBtn").disabled = true;

  try {
    const reply = await callAI({
      system: state.personaPrompt,
      messages: state.chat,
      maxTokens: 4000
    });
    state.chat.push({ role: "assistant", content: reply });
    render();
  } catch (e) {
    state.chat.pop();
    render();
    const box = document.createElement("div");
    box.className = "msg error";
    box.textContent = "送信に失敗しました: " + e.message;
    document.getElementById("chatLog").appendChild(box);
    document.getElementById("chatInput").value = text;
  }
}

boot();
