/* content.js — 「投稿を合成」ツールを、今見ているページの右上にフローティング表示する。
 * 参考ツール（SNS投稿コレクター）と同じ方式：ポップアップの別ウィンドウではなく、
 * activeTab + scripting でクリックしたページに直接注入する。
 * common.js が同じ chrome.scripting.executeScript 呼び出しで先に読み込まれている前提。
 */
(function () {
  const ROOT_ID = "tbz-merge-modal-root";
  const STYLE_ID = "tbz-merge-modal-style";

  // 既に開いていれば閉じる（ボタンの再クリックでトグル）
  const existing = document.getElementById(ROOT_ID);
  if (existing) {
    existing.remove();
    document.getElementById(STYLE_ID)?.remove();
    if (window.__tbzMergeEscHandler) {
      document.removeEventListener("keydown", window.__tbzMergeEscHandler);
      window.__tbzMergeEscHandler = null;
    }
    return;
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str == null ? "" : str;
    return div.innerHTML;
  }

  function injectStyle() {
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${ROOT_ID}, #${ROOT_ID} * {
        box-sizing: border-box;
        font-family: "Noto Sans JP", "Hiragino Sans", "Yu Gothic", -apple-system, BlinkMacSystemFont, sans-serif;
      }
      #${ROOT_ID} {
        margin: 0;
        display: block;
        position: fixed;
        top: 32px;
        right: 32px;
        z-index: 2147483647;
        width: min(420px, calc(100vw - 40px));
        max-height: calc(100vh - 64px);
        overflow-y: auto;
        color: #17191d;
        background: #ffffff;
        border: 1px solid #e3e5e9;
        border-radius: 20px;
        box-shadow: 0 24px 60px rgba(0,0,0,.16), 0 4px 16px rgba(0,0,0,.06);
        font-size: 14px;
        line-height: 1.6;
        text-align: left;
        direction: ltr;
        letter-spacing: normal;
        text-transform: none;
        animation: tbz-pop-in .16s ease-out;
      }
      @media (prefers-reduced-motion: reduce) {
        #${ROOT_ID} { animation: none; }
      }
      @keyframes tbz-pop-in {
        from { opacity: 0; transform: translateY(-6px) scale(.98); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }
      #${ROOT_ID} .tbz-header {
        display: flex; align-items: center; gap: 8px;
        padding: 16px 16px 12px;
        border-bottom: 1px solid #eef0f2;
      }
      #${ROOT_ID} .tbz-header .tbz-icon { font-size: 18px; }
      #${ROOT_ID} .tbz-header h2 {
        flex: 1; margin: 0; font-size: 15px; font-weight: 700; color: #17191d;
      }
      #${ROOT_ID} .tbz-close {
        cursor: pointer; border: none; background: transparent; color: #70747c;
        width: 26px; height: 26px; border-radius: 8px; font-size: 15px; line-height: 1;
        display: flex; align-items: center; justify-content: center;
      }
      #${ROOT_ID} .tbz-close:hover { background: #f1f2f4; color: #17191d; }
      #${ROOT_ID} .tbz-body { padding: 16px; }
      #${ROOT_ID} p { color: #70747c; margin: 0 0 12px; }
      #${ROOT_ID} label {
        display: block; font-size: 12px; font-weight: 600; color: #70747c; margin: 12px 0 4px;
      }
      #${ROOT_ID} label:first-child { margin-top: 0; }
      #${ROOT_ID} .tbz-hint-line { display: flex; align-items: center; gap: 6px; font-size: 12px; color: #70747c; margin-bottom: 12px; }
      #${ROOT_ID} textarea, #${ROOT_ID} select {
        width: 100%; background: #ffffff; border: 1px solid #e3e5e9; color: #17191d;
        border-radius: 8px; padding: 10px 12px; font-size: 13px; resize: vertical;
      }
      #${ROOT_ID} select {
        appearance: none; -webkit-appearance: none; padding-right: 30px; cursor: pointer;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6' fill='none'%3E%3Cpath d='M1 1L5 5L9 1' stroke='%2370747c' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
        background-repeat: no-repeat; background-position: right 10px center;
      }
      #${ROOT_ID} textarea { min-height: 78px; }
      #${ROOT_ID} textarea:focus, #${ROOT_ID} select:focus {
        outline: none; border-color: #8a6d00; box-shadow: 0 0 0 3px #fbf3d6;
      }
      #${ROOT_ID} .tbz-step-num {
        display: inline-flex; align-items: center; justify-content: center;
        width: 18px; height: 18px; border-radius: 50%;
        background: #17191d; color: #fff; font-size: 10px; font-weight: 700;
        margin-right: 6px; flex-shrink: 0;
      }
      #${ROOT_ID} .tbz-field-label { display: flex; align-items: center; margin-top: 12px; }
      #${ROOT_ID} .tbz-field-label:first-child { margin-top: 0; }
      #${ROOT_ID} .tbz-field-label span.tbz-label-text { font-size: 12px; font-weight: 600; color: #17191d; }
      #${ROOT_ID} .tbz-btn-row { display: flex; gap: 8px; margin-top: 14px; align-items: center; }
      #${ROOT_ID} .tbz-btn-row .tbz-spacer { flex: 1; }
      #${ROOT_ID} button.tbz-btn {
        cursor: pointer; border: none; border-radius: 999px; padding: 9px 16px;
        font-size: 13px; font-weight: 600; font-family: inherit;
      }
      #${ROOT_ID} button.tbz-primary { background: #17191d; color: #ffffff; }
      #${ROOT_ID} button.tbz-primary:hover { filter: brightness(1.3); }
      #${ROOT_ID} button.tbz-primary:disabled { opacity: .5; cursor: not-allowed; }
      #${ROOT_ID} button.tbz-secondary { background: #f1f2f4; color: #17191d; border: 1px solid #e3e5e9; }
      #${ROOT_ID} button.tbz-secondary:hover { background: #e3e5e9; }
      #${ROOT_ID} .tbz-msg { padding: 10px 12px; border-radius: 10px; margin-top: 10px; font-size: 12px; white-space: pre-wrap; }
      #${ROOT_ID} .tbz-msg.tbz-error { background: #fdeceb; border: 1px solid #dc2626; color: #dc2626; }
      #${ROOT_ID} .tbz-msg.tbz-ok { background: #e9f9ef; border: 1px solid #16a34a; color: #16a34a; }
      #${ROOT_ID} .tbz-msg.tbz-loading { background: #f1f2f4; border: 1px solid #e3e5e9; color: #70747c; }
      #${ROOT_ID} .tbz-spinner {
        display: inline-block; width: 12px; height: 12px; border: 2px solid rgba(23,25,29,.15);
        border-top-color: #17191d; border-radius: 50%; animation: tbz-spin .7s linear infinite;
        vertical-align: middle; margin-right: 6px;
      }
      @keyframes tbz-spin { to { transform: rotate(360deg); } }
      #${ROOT_ID} .tbz-output {
        background: #f1f2f4; border: 1px solid #e3e5e9; border-radius: 10px; padding: 12px;
        white-space: pre-wrap; font-size: 13px; max-height: 260px; overflow-y: auto; margin-top: 12px;
      }
    `;
    document.head.appendChild(style);
  }

  function buildRoot() {
    const root = document.createElement("div");
    root.id = ROOT_ID;
    root.innerHTML = `
      <div class="tbz-header">
        <span class="tbz-icon">🧩</span>
        <h2>投稿を合成</h2>
        <button type="button" class="tbz-close" id="tbz-close-btn" aria-label="閉じる">✕</button>
      </div>
      <div class="tbz-body" id="tbz-body"><span class="tbz-spinner"></span>読み込み中...</div>
    `;
    document.body.appendChild(root);
    root.querySelector("#tbz-close-btn").addEventListener("click", closeModal);
    return root;
  }

  function closeModal() {
    document.getElementById(ROOT_ID)?.remove();
    document.getElementById(STYLE_ID)?.remove();
    if (window.__tbzMergeEscHandler) {
      document.removeEventListener("keydown", window.__tbzMergeEscHandler);
      window.__tbzMergeEscHandler = null;
    }
  }

  function buildMergeSystemPrompt(personaPrompt, postA, postB) {
    return `${personaPrompt}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【今回の作業：2つの投稿を合成して1つの新しい投稿を作る】
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

通常のテーマ提案フロー（STEP1・STEP2）は行わず、今回は以下の2つの投稿だけを素材にして、新しい投稿を1つ作成してください。

【投稿A：構成・型を借りる元】
${postA}

【投稿B：内容・ネタを借りる元】
${postB}

【作業手順（必ず守る）】
1. 投稿Aから「ロック項目」（冒頭フックの構文・句読点・改行位置、箇条書きの数と論理順、締めの構文とリズム、1文の長さ感）を抽出する。
2. 投稿Aの型を一切崩さず、その骨格に投稿Bの内容（伝えたい情報・エピソード・数字・テーマ）を差し込む。
3. 上記の発信者プロフィール・使える数字リスト・絶対NGワード・CTA設定も踏まえて自然に仕上げる。

【出力形式（この形式のみを出力する。前置き・説明文は書かない）】

【新しい投稿】
（投稿本文）

【投稿Aから維持した構成】
（1〜2行で簡潔に）

【投稿Bから使った内容】
（1〜2行で簡潔に）`;
  }

  function extractNewPost(text) {
    const m = text.match(/【新しい投稿】\s*([\s\S]*?)(?=【投稿Aから維持した構成】|【投稿Bから使った内容】|$)/);
    return m ? m[1].trim() : "";
  }

  async function copyToClipboard(text, btn) {
    try {
      await navigator.clipboard.writeText(text);
      if (btn) {
        const orig = btn.textContent;
        btn.textContent = "✅ コピーしました";
        setTimeout(() => (btn.textContent = orig), 1500);
      }
    } catch (e) {
      const bodyEl = document.getElementById("tbz-body");
      const note = document.createElement("div");
      note.className = "tbz-msg tbz-error";
      note.textContent = "コピーに失敗しました。テキストを選択して手動でコピーしてください。";
      bodyEl?.appendChild(note);
    }
  }

  function renderNeedsSettings(bodyEl) {
    bodyEl.innerHTML = `
      <p>使いたいAIのAPIキーを登録すると使えるようになります。</p>
      <div class="tbz-btn-row">
        <span class="tbz-spacer"></span>
        <button type="button" class="tbz-btn tbz-primary" id="tbz-go-settings">⚙️ 設定を開く</button>
      </div>`;
    bodyEl.querySelector("#tbz-go-settings").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "openOptionsPage" });
    });
  }

  function renderNeedsPersona(bodyEl) {
    bodyEl.innerHTML = `
      <p>APIキーの設定とは別に、ペルソナ設定を1つ以上作成・読み込みする必要があります。</p>
      <div class="tbz-btn-row">
        <button type="button" class="tbz-btn tbz-secondary" id="tbz-go-settings">⚙️ 設定を開く</button>
        <span class="tbz-spacer"></span>
        <button type="button" class="tbz-btn tbz-primary" id="tbz-go-wizard">🧙 質問に答えて作る</button>
      </div>`;
    bodyEl.querySelector("#tbz-go-settings").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "openOptionsPage" });
    });
    bodyEl.querySelector("#tbz-go-wizard").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "openWizardTab" });
    });
  }

  function renderForm(bodyEl, accounts, selectedId) {
    const accountOptions = accounts
      .map((a) => `<option value="${a.id}" ${a.id === selectedId ? "selected" : ""}>${escapeHtml(a.name)}</option>`)
      .join("");

    bodyEl.innerHTML = `
      ${
        accounts.length > 1
          ? `<label>使うペルソナ（アカウント）</label><select id="tbz-account-select">${accountOptions}</select>`
          : `<p class="tbz-hint-line">👤 ${escapeHtml(accounts[0].name)} のペルソナで作成します。</p>`
      }
      <div class="tbz-field-label"><span class="tbz-step-num">1</span><span class="tbz-label-text">構成・型を借りたい投稿を貼る</span></div>
      <textarea id="tbz-post-a" placeholder="参考にしたい投稿の「型」（フックの言い回し、箇条書きの数、締め方など）を貼り付け..."></textarea>

      <div class="tbz-field-label"><span class="tbz-step-num">2</span><span class="tbz-label-text">内容・ネタを借りたい投稿を貼る</span></div>
      <textarea id="tbz-post-b" placeholder="使いたい「中身」（伝えたい情報、エピソード、数字など）を貼り付け..."></textarea>

      <div class="tbz-btn-row">
        <span class="tbz-spacer"></span>
        <button type="button" class="tbz-btn tbz-primary" id="tbz-merge-btn">✨ 合成する →</button>
      </div>
      <div id="tbz-merge-status"></div>
      <div id="tbz-merge-result"></div>
    `;

    bodyEl.querySelector("#tbz-merge-btn").addEventListener("click", async () => {
      const postA = bodyEl.querySelector("#tbz-post-a").value.trim();
      const postB = bodyEl.querySelector("#tbz-post-b").value.trim();
      const statusEl = bodyEl.querySelector("#tbz-merge-status");
      const resultEl = bodyEl.querySelector("#tbz-merge-result");
      resultEl.innerHTML = "";

      if (!postA || !postB) {
        statusEl.innerHTML = `<div class="tbz-msg tbz-error">構成を借りたい投稿・内容を借りたい投稿の両方を貼り付けてください。</div>`;
        return;
      }

      const selectEl = bodyEl.querySelector("#tbz-account-select");
      const accountId = selectEl ? selectEl.value : accounts[0].id;
      const account = accounts.find((a) => a.id === accountId) || accounts[0];

      statusEl.innerHTML = `<div class="tbz-msg tbz-loading"><span class="tbz-spinner"></span>投稿を合成しています...</div>`;
      try {
        const system = buildMergeSystemPrompt(account.personaPrompt, postA, postB);
        const reply = await callAI({
          system,
          messages: [
            { role: "user", content: "上記の投稿Aと投稿Bをもとに、指示された通りに新しい投稿を1つ作成してください。" }
          ]
        });
        statusEl.innerHTML = "";
        const newPost = extractNewPost(reply) || reply;
        resultEl.innerHTML = `
          <div class="tbz-output">${escapeHtml(newPost)}</div>
          <div class="tbz-btn-row">
            <span class="tbz-spacer"></span>
            <button type="button" class="tbz-btn tbz-secondary" id="tbz-copy-btn">📋 この投稿をコピー</button>
          </div>`;
        resultEl.querySelector("#tbz-copy-btn").addEventListener("click", (e) => copyToClipboard(newPost, e.target));
      } catch (e) {
        statusEl.innerHTML = `<div class="tbz-msg tbz-error">合成に失敗しました:\n${escapeHtml(e.message)}</div>`;
      }
    });
  }

  async function boot() {
    injectStyle();
    const root = buildRoot();
    const bodyEl = root.querySelector("#tbz-body");

    window.__tbzMergeEscHandler = (e) => {
      if (e.key === "Escape") closeModal();
    };
    document.addEventListener("keydown", window.__tbzMergeEscHandler);

    const settings = await getSettings();
    if (!settings.provider || !settings.apiKey) {
      renderNeedsSettings(bodyEl);
      return;
    }

    const accounts = await getAccounts();
    if (!accounts.length) {
      renderNeedsPersona(bodyEl);
      return;
    }

    const activeId = await getActiveAccountId();
    renderForm(bodyEl, accounts, accounts.find((a) => a.id === activeId)?.id || accounts[0].id);
  }

  boot();
})();
