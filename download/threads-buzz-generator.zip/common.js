/* common.js
 * ストレージ操作と、複数のAIプロバイダーへの統一APIクライアント。
 * すべてのAPI通信はユーザーのブラウザから直接プロバイダーへ送信されます。
 * APIキーは chrome.storage.local にのみ保存され、拡張機能の外部やAnthropic/開発者には送信されません。
 */

const DEFAULT_MODELS = {
  anthropic: "claude-sonnet-4-5-20250929",
  openai: "gpt-4o",
  // Flash-Lite has the largest free-tier daily quota, so it's the default
  // for cost-free usage. Google retired 2.5-flash-lite for new users in
  // 2026-08 in favor of 3.5-flash-lite; update this if Google moves on again.
  gemini: "gemini-3.5-flash-lite",
  openrouter: "anthropic/claude-sonnet-4.5",
  custom: ""
};

const PROVIDER_LABELS = {
  anthropic: "Anthropic (Claude)",
  openai: "OpenAI (GPT)",
  gemini: "Google (Gemini)・無料枠あり",
  openrouter: "OpenRouter(複数モデルを1つのキーで利用可)",
  custom: "カスタム (OpenAI互換エンドポイント)"
};

async function getSettings() {
  const data = await chrome.storage.local.get([
    "provider",
    "apiKey",
    "model",
    "customBaseUrl"
  ]);
  return {
    provider: data.provider || "",
    apiKey: data.apiKey || "",
    model: data.model || "",
    customBaseUrl: data.customBaseUrl || ""
  };
}

async function saveSettings(settings) {
  await chrome.storage.local.set(settings);
}

/* ---- アカウント（ペルソナ）管理 ----
 * 1つの拡張機能で複数のSNSアカウント分のペルソナ設定を保存できるようにする。
 * account = { id, name, profile, personaPrompt, createdAt }
 */
function makeAccountId() {
  return "acc_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
}

async function getAccounts() {
  const data = await chrome.storage.local.get([
    "accounts",
    "activeAccountId",
    "profile",
    "personaPrompt"
  ]);
  let accounts = Array.isArray(data.accounts) ? data.accounts : [];
  // 旧バージョン（単一アカウントのみ）からの移行
  if (accounts.length === 0 && data.personaPrompt) {
    const migrated = {
      id: makeAccountId(),
      name: "アカウント1",
      profile: data.profile || null,
      personaPrompt: data.personaPrompt,
      createdAt: Date.now()
    };
    accounts = [migrated];
    await chrome.storage.local.set({ accounts, activeAccountId: migrated.id });
    await chrome.storage.local.remove(["profile", "personaPrompt"]);
  }
  return accounts;
}

async function saveAccounts(accounts) {
  await chrome.storage.local.set({ accounts });
}

async function getActiveAccountId() {
  const { activeAccountId } = await chrome.storage.local.get(["activeAccountId"]);
  return activeAccountId || null;
}

async function setActiveAccountId(id) {
  await chrome.storage.local.set({ activeAccountId: id });
}

async function getActiveAccount() {
  const accounts = await getAccounts();
  if (!accounts.length) return null;
  const activeId = await getActiveAccountId();
  return accounts.find((a) => a.id === activeId) || accounts[0];
}

async function addAccount({ name, profile, personaPrompt }) {
  const accounts = await getAccounts();
  const account = {
    id: makeAccountId(),
    name: name && name.trim() ? name.trim() : `アカウント${accounts.length + 1}`,
    profile: profile || null,
    personaPrompt: personaPrompt || "",
    createdAt: Date.now()
  };
  accounts.push(account);
  await saveAccounts(accounts);
  await setActiveAccountId(account.id);
  return account;
}

async function updateAccount(id, patch) {
  const accounts = await getAccounts();
  const idx = accounts.findIndex((a) => a.id === id);
  if (idx === -1) return null;
  accounts[idx] = { ...accounts[idx], ...patch };
  await saveAccounts(accounts);
  return accounts[idx];
}

async function deleteAccount(id) {
  let accounts = await getAccounts();
  accounts = accounts.filter((a) => a.id !== id);
  await saveAccounts(accounts);
  const activeId = await getActiveAccountId();
  if (activeId === id) {
    await setActiveAccountId(accounts.length ? accounts[0].id : "");
  }
}

async function clearAll() {
  await chrome.storage.local.remove([
    "accounts",
    "activeAccountId",
    "profile",
    "personaPrompt"
  ]);
}

/* ---- テーマカラー ---- */
const VALID_ACCENTS = ["yellow", "coral", "sky", "mint", "lavender"];
const ACCENT_LABELS = {
  yellow: "レモン",
  coral: "コーラル",
  sky: "スカイ",
  mint: "ミント",
  lavender: "ラベンダー"
};

async function getAccent() {
  const { accent } = await chrome.storage.local.get(["accent"]);
  return VALID_ACCENTS.includes(accent) ? accent : "yellow";
}

async function saveAccent(accent) {
  if (!VALID_ACCENTS.includes(accent)) return;
  await chrome.storage.local.set({ accent });
  // background.js が chrome.storage.onChanged を見てツールバーアイコンも更新する
}

/** 保存済みのテーマカラーを <html data-accent="..."> に反映する。各ページの読み込み時に呼ぶ。 */
async function applyAccent() {
  try {
    const accent = await getAccent();
    document.documentElement.setAttribute("data-accent", accent);
  } catch (e) {
    // ストレージ未対応環境などでは既定のテーマのまま表示する
  }
}

/* ---- APIエラーとリトライ ---- */

/** HTTPステータスを持たせたエラーを作る。リトライ判定に使う。 */
function apiError(message, status) {
  const err = new Error(message);
  err.status = status;
  return err;
}

/* 待てば直る種類のエラーかどうか。
 * 503 UNAVAILABLE（混雑）は Gemini の無料枠で頻発する。
 * 429 はレート制限、5xx はサーバー側の一時的な不調。
 * 401/403（キーが違う）や 400（リクエストが不正）は何度投げても直らないので対象外。
 */
const RETRYABLE_STATUSES = [429, 500, 502, 503, 504];
const MAX_ATTEMPTS = 4;

function isRetryable(err) {
  return RETRYABLE_STATUSES.includes(err && err.status);
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * 統一AI呼び出し関数。
 * 混雑（503）などの一時的なエラーは、間隔を空けて最大4回まで自動で投げ直す。
 * @param {Object} opts
 * @param {string} opts.system - システムプロンプト(ペルソナ指示)
 * @param {Array<{role:'user'|'assistant', content:string, images?:string[]}>} opts.messages - 会話履歴
 * @param {number} [opts.maxTokens]
 * @param {(attempt:number, waitMs:number)=>void} [opts.onRetry] - 再試行時に呼ばれる（UIの進捗表示用）
 * @returns {Promise<string>} - モデルの返答テキスト
 */
async function callAI({ system, messages, maxTokens = 4000, onRetry }) {
  let lastErr;

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      return await callAIOnce({ system, messages, maxTokens });
    } catch (e) {
      lastErr = e;
      if (!isRetryable(e) || attempt === MAX_ATTEMPTS) break;

      // 1.5秒 → 3秒 → 6秒。同時に混雑しているとき同じ瞬間に集中しないよう、少しずらす。
      const waitMs = 1500 * Math.pow(2, attempt - 1) + Math.floor(Math.random() * 500);
      if (typeof onRetry === "function") onRetry(attempt, waitMs);
      await sleep(waitMs);
    }
  }

  // 何度投げても混雑が解消しなかった場合は、原因と対処が分かる文面にする
  if (lastErr && lastErr.status === 503) {
    throw new Error(
      `AI側が混雑していて、${MAX_ATTEMPTS}回試しても応答がありませんでした。\n` +
        "しばらく（数分〜数十分）おいてから、もう一度お試しください。\n" +
        "急ぐ場合は、設定画面で別のモデル名やプロバイダーに切り替えると通ることがあります。\n\n" +
        lastErr.message
    );
  }
  if (lastErr && lastErr.status === 429) {
    throw new Error(
      `リクエストが多すぎるとして断られました（${MAX_ATTEMPTS}回試行）。\n` +
        "無料枠の上限に達している可能性があります。時間をおいてからお試しください。\n\n" +
        lastErr.message
    );
  }
  throw lastErr;
}

/** 実際に1回だけAPIを叩く。リトライはしない。 */
async function callAIOnce({ system, messages, maxTokens }) {
  const settings = await getSettings();
  if (!settings.provider || !settings.apiKey) {
    throw new Error(
      "AIプロバイダーが設定されていません。右上の「設定」からAPIキーを登録してください。"
    );
  }
  const model = settings.model || DEFAULT_MODELS[settings.provider];

  switch (settings.provider) {
    case "anthropic":
      return callAnthropic(settings, model, system, messages, maxTokens);
    case "openai":
      return callOpenAI(
        "https://api.openai.com/v1/chat/completions",
        settings.apiKey,
        model,
        system,
        messages,
        maxTokens
      );
    case "openrouter":
      return callOpenAI(
        "https://openrouter.ai/api/v1/chat/completions",
        settings.apiKey,
        model,
        system,
        messages,
        maxTokens,
        {
          "HTTP-Referer": "https://threads-buzz-extension.local",
          "X-Title": "Threads Buzz Generator"
        }
      );
    case "custom":
      return callOpenAI(
        settings.customBaseUrl,
        settings.apiKey,
        model,
        system,
        messages,
        maxTokens
      );
    case "gemini":
      return callGemini(settings, model, system, messages, maxTokens);
    default:
      throw new Error("未対応のプロバイダーです: " + settings.provider);
  }
}

function imagesToAnthropicBlocks(images) {
  return (images || []).map((img) => ({
    type: "image",
    source: {
      type: "base64",
      media_type: img.mediaType,
      data: img.base64
    }
  }));
}

async function callAnthropic(settings, model, system, messages, maxTokens) {
  const body = {
    model,
    max_tokens: maxTokens,
    system,
    messages: messages.map((m) => {
      const content = [];
      if (m.images && m.images.length) {
        content.push(...imagesToAnthropicBlocks(m.images));
      }
      content.push({ type: "text", text: m.content });
      return { role: m.role, content };
    })
  };
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": settings.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const errText = await res.text();
    throw apiError(`Anthropic APIエラー (${res.status}): ${errText}`, res.status);
  }
  const data = await res.json();
  return (data.content || [])
    .filter((c) => c.type === "text")
    .map((c) => c.text)
    .join("\n");
}

function imagesToOpenAIBlocks(images) {
  return (images || []).map((img) => ({
    type: "image_url",
    image_url: { url: `data:${img.mediaType};base64,${img.base64}` }
  }));
}

async function callOpenAI(
  url,
  apiKey,
  model,
  system,
  messages,
  maxTokens,
  extraHeaders = {}
) {
  if (!url) {
    throw new Error(
      "カスタムプロバイダーのエンドポイントURLが設定されていません。設定画面で入力してください。"
    );
  }
  const chatMessages = [{ role: "system", content: system }];
  for (const m of messages) {
    if (m.images && m.images.length) {
      chatMessages.push({
        role: m.role,
        content: [
          { type: "text", text: m.content },
          ...imagesToOpenAIBlocks(m.images)
        ]
      });
    } else {
      chatMessages.push({ role: m.role, content: m.content });
    }
  }
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${apiKey}`,
      ...extraHeaders
    },
    body: JSON.stringify({
      model,
      messages: chatMessages,
      max_tokens: maxTokens
    })
  });
  if (!res.ok) {
    const errText = await res.text();
    throw apiError(`APIエラー (${res.status}): ${errText}`, res.status);
  }
  const data = await res.json();
  return data.choices?.[0]?.message?.content || "";
}

async function callGemini(settings, model, system, messages, maxTokens) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${settings.apiKey}`;
  const contents = messages.map((m) => {
    const parts = [{ text: m.content }];
    for (const img of m.images || []) {
      parts.push({
        inline_data: { mime_type: img.mediaType, data: img.base64 }
      });
    }
    return { role: m.role === "assistant" ? "model" : "user", parts };
  });
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: system }] },
      contents,
      generationConfig: { maxOutputTokens: maxTokens }
    })
  });
  if (!res.ok) {
    const errText = await res.text();
    throw apiError(`Gemini APIエラー (${res.status}): ${errText}`, res.status);
  }
  const data = await res.json();
  const parts = data.candidates?.[0]?.content?.parts || [];
  return parts.map((p) => p.text || "").join("\n");
}

/** 動作確認用の軽量テスト呼び出し */
async function testConnection(onRetry) {
  const reply = await callAI({
    system: "あなたは接続テスト用のアシスタントです。",
    messages: [
      { role: "user", content: "「OK」とだけ返信してください。" }
    ],
    maxTokens: 20,
    onRetry
  });
  return reply;
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result; // data:<mime>;base64,<data>
      const base64 = result.split(",")[1];
      resolve({ base64, mediaType: file.type || "image/png" });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
